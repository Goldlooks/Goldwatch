# Gold Watch

Bot Telegram pour l'or (XAUUSD) : alertes news filtrées par intensité, avertissement avant les gros événements du calendrier, recap du matin, aperçu de la semaine (dimanche soir) et recap de fin de semaine (vendredi soir).

## Installation (≈ 15 min)

### 1. Bot Telegram
1. Dans Telegram, ouvre **@BotFather** → `/newbot` → garde le **token**.
2. Envoie un message à ton nouveau bot.
3. Ouvre `https://api.telegram.org/bot<TOKEN>/getUpdates` dans ton navigateur et note le `chat` → `id` (ton **chat id**).

### 2. Clé API Claude (pour le tri intelligent et les recaps)
Crée une clé sur https://console.anthropic.com. Sans clé, le bot marche quand même avec un tri par mots-clés, mais les recaps seront de simples listes de données.

### 3. GitHub
1. Crée un dépôt **public** (Actions illimitées et gratuites; un dépôt privé a un quota de 2000 min/mois, alors passe les alertes à `*/30` dans le workflow).
2. Dépose tous les fichiers de ce dossier (avec `.github/workflows/gold-watch.yml`).
3. Dépôt → Settings → Secrets and variables → Actions → ajoute :
   - `TELEGRAM_TOKEN`
   - `TELEGRAM_CHAT_ID`
   - `ANTHROPIC_API_KEY`
4. Onglet Actions → **gold-watch** → Run workflow → mode `test`. Tu dois recevoir « Gold Watch est connecté ».

C'est tout : le reste roule tout seul.

## Réglages
- `IMPACT_MIN` (3 = seulement les news intenses, 2 = intenses + modérées). Ajoute `IMPACT_MIN: "3"` dans la section `env` du workflow.
- `FEEDS` dans `main.py` : ajoute ou retire des sources RSS.
- `CLAUDE_MODEL` : change le modèle utilisé.

## Notes
- Les heures cron sont en **UTC** : en été (heure avancée), tout arrive 1 h plus tôt à Toronto. Décale les crons de +1 h en mars.
- GitHub peut retarder un cron de quelques minutes : ce n'est pas de l'ultra temps réel (pour du tick par tick, il faut un VPS).
- Le prix vient de Yahoo (futures GC=F, pas le spot), à titre indicatif.
- Le bot analyse les nouvelles, il ne donne pas de signaux de trade. Pas un conseil financier.
